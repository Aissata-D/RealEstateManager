package com.openclassrooms.realestatemanager;

import junit.framework.TestCase;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class UtilsTest extends TestCase {

    public void setUp() throws Exception {
        super.setUp();
    }

    public void tearDown() throws Exception {
    }

    public void testConvertEuroToDollar() {
        final double conversionRateEuroToDollar = 1.01;
        int euro = 1;
        double dollar = Utils.convertEuroToDollar(euro);
        assertEquals(conversionRateEuroToDollar,dollar);
    }

    public void testGetTodayDate() {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String dateExpected = dateFormat.format(new Date());
        String dateActual = Utils.getTodayDate();
        assertEquals(dateExpected,dateActual);
    }

    public void testIsNetworkAvailable() {
    }
}